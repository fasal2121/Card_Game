package org.example;
import java.util.Scanner;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) {
        int carte_JoueurA, carte_JoueurB, nbr_tour = 0, compteur = 0;
        int pointsA =0, pointsB=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Choisir le nombre d'essai svp");
        nbr_tour = sc.nextInt();

        while (compteur<nbr_tour) {
            System.out.println("**********    Début de la partie    *****************");
            System.out.println("Joueur A : Entrez un chiffre entre 1 et 10 svp");
            carte_JoueurA = sc.nextInt();
            System.out.println("Joueur B : Entrez un chiffre entre 1 et 10 svp");
            carte_JoueurB = sc.nextInt();
            if (carte_JoueurA > carte_JoueurB) {
                System.out.println("Joueur A a gagné");
                compteur += 1;
                pointsA += carte_JoueurA;
                pointsB += carte_JoueurB;
                System.out.println("Dans le panier A est " + pointsA);
                System.out.println("Dans le panier B est " + pointsB);
            } else if (carte_JoueurB > carte_JoueurA) {
                System.out.println("Joueur B a gagné");
                compteur += 1;
                pointsA += carte_JoueurA;
                pointsB += carte_JoueurB;
                System.out.println("Dans le panier A est " + pointsA);
                System.out.println("Dans le panier B est " + pointsB);
            } else {
                System.out.println("Egalité !");
            }
        }
        System.out.println("**********    Fin de la partie    *****************");
        if (pointsA>pointsB){
            System.out.println("Le gagnant de la partie est le Joueur A");}
        else{
            System.out.println("Le gagnant de la partie est le Joueur B");}

        }
}

